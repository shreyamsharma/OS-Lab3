/*
 * Tutorial 3 Jeopardy Project for SOFE 3950U / CSCI 3020U: Operating Systems
 *
 * Copyright (C) 2015, 
  Shreya Sharma (100725334)
  Disha Panday (100725039)
  Shahroze Butt (100701891)
  
 * All rights reserved.
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "questions.h"

// Initializes the array of questions for the game
void initialize_game(void)
{
     // initialize each question struct and assign it to the questions array
    for(int i = 0; i < 12; i++) {
    	strcpy(questions[i].category, categories[i % 3]);
    	questions[i].answered = false;
    	strcpy(questions[i].question, "Question");
    	strcpy(questions[i].answer, "Answer");
    }
    
    
    //Each category has 3 questions
//Category 1- Beverages
   
    questions[0].value = 200;
    strcpy(questions[0].question, "From which French region does Claret come from? ");
    strcpy(questions[0].answer, "Bordeaux");

    questions[1].value = 300;
    strcpy(questions[1].question, "Which cocktail consists of Tia Maria, Vodka and Coke-Cola");
    strcpy(questions[1].answer, "Black Russian");

    questions[2].value = 400;
    strcpy(questions[2].question, "Bacardi and Carioca rums come from what country?");
    strcpy(questions[2].answer, "Costa Rico");
//Category 2 - Geography
    questions[3].value = 200;
    strcpy(questions[3].question, "In which country is Timbuktu? ");
    strcpy(questions[3].answer, "Mali");

    questions[4].value = 300;
    strcpy(questions[4].question, "Which canadian province is the world's leading exporter of Christmas Trees?");
    strcpy(questions[4].answer, "Nova Scotia");

    questions[5].value = 400;
    strcpy(questions[5].question, "In which country is the Great Belt East Bridge? ");
    strcpy(questions[5].answer, "Denmark");
//Category 3-Pop Music
    questions[6].value = 200;
    strcpy(questions[6].question, "Who officially became the Female artist with the most grammy awards in 2021? ");
    strcpy(questions[6].answer, "Beyonce");

    questions[7].value = 300;
    strcpy(questions[7].question, "Which MIley Cyrus song mentions Jay-Z and Britney Spears? ");
    strcpy(questions[7].answer, "Party in the USA");

    questions[8].value = 400;
    strcpy(questions[8].question, "Which female pop music star is re-recording her first six albums to gain ownership and control of her music? ");
    strcpy(questions[8].answer, "Taylor Swift");
}


// Displays each of the remaining categories and question dollar values that have not been answered
void display_categories(void)
{
    // print categories and dollar values for each unanswered question in questions array
    int width = 20;

    for (int i = 0; i < 3; ++i) {
		putchar('+');
		for (int j = 0; j < width; ++j)
			putchar('-');
	}
	printf("+\n");

	for(int i = 0; i < 3; i++) 
		printf("| %-*s", width - 1, categories[i]);
	printf("|\n");

	for (int i = 0; i < 3; ++i) {
		putchar('+');
		for (int j = 0; j < width; ++j)
			putchar('-');
	}

	for(int i = 0; i < 12; i++) {
		if(questions[i].answered == false) {
			printf("%d", width - 2);
			printf("%d", questions[i].value);
		} else {
			printf("| %-*s", width - 2, " - ");
		}

		if(i % 3 == 2)
			printf("|\n");
	}

	for (int i = 0; i < 3; ++i) {
		putchar('+');
		for (int j = 0; j < width; ++j)
			putchar('-');
	}
}
bool answered_status() {
	for(int i = 0; i < 12; i++)
		if(questions[i].answered == false)
			return false;

	return true;
}

int get_question_number(char *category, int value) {
	for(int i = 0; i < 12; i++)
		if(strcmp(questions[i].category, category) == 0 && questions[i].value == value)
			return i;


	return -1;
}
// Displays the question for the category and dollar value
void display_question(char *category, int value)
{
	printf("Question (%s for $%d):\n", category, value);

	int num = get_question_number(category, value);
	if(num == -1)
		printf("question %s not found, %d\n", category, value);

	printf("\t%s\n", questions[num].question);
}

// Returns true if the answer is correct for the question for that category and dollar value
bool valid_answer(char *category, int value, char *answer)
{
	int num = get_question_number(category, value);
	if(num == -1)
		printf("question %s not found, %d\n", category, value);

    // Look into string comparison functions
    return (strcasecmp(answer, questions[num].answer) == 0);
}

// Returns true if the question has already been answered
bool already_answered(char *category, int value)
{
	for(int i = 0; i < 12; i++)
	{
		if(strcmp(questions[i].category, category) == 0 && questions[i].value == value)
			return questions[i].answered;
			}

    // lookup the question and see if it's already been marked as answered
    return true;
}

void track_answered(char *category, int value) {
	for(int i = 0; i < 12; i++) 
		if(questions[i].value == value && strcmp(questions[i].category, category) == 0)
			questions[i].answered = true;
}


